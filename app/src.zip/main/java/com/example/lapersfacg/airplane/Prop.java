package com.example.lapersfacg.airplane;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * Created by laper sfacg on 2017/9/24.
 */

public class Prop {

    private int type;
    private int x;
    private int y;
    private Bitmap bitmap;
    private Context mContext;

    public Prop(Context mContext,int type,int x,int y){

    }

    public void draw(Canvas canvas, Paint paint){

    }

    public void logic(int x,int y){

    }
}
